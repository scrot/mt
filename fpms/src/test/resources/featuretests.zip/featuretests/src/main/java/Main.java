/**
 * Created by roy on 5/23/16.
 */
public class Main {
    int m1;
    int m2;
    int m3;
    int m4;
    int m5;

    class Inner{
        int i1;
        int i2;
        int i3;
        int i4;
    }
}

class Outer{
    int o1;
    int o2;
    int o3;
    int o4;

    public Outer() {
        Main m = new Main(){{
            int a1;
            int a2;
            int a3;
            int a4;
        }};
    }
}
